#include <iostream>
#include <math.h>
#include <time.h>
#include "hist.hpp"

using namespace std;

// This function generates basic random
double gamma(){
    return (rand()+0.5)/(RAND_MAX+1.0);
}

// scattered photon energy probability
double g_compton(double x, double E){
    return x/E + E/x + (1/E - 1/x)*(2 + 1/E - 1/x);
}

// simulate compton
double compton(double E)
{
 double ksi, xmin, xmax, gmax, g_value;
 double gam1, gam2;
 xmin=E/(1.+2.*E);
 xmax=E;
// ******************************************************



// ******************************************************
 return ksi;
}

int main(){
    double ksi;  // random value
    srand(time(NULL)); // initialize the random generator
    double E=3.5*0.511;
    int num_bin = 10*E+0.1;
    Hist *hist = new Hist(E/(1.+2.*E), E, num_bin);
    for( int i=0; i<4000000; i++ ){
        ksi = compton(E);
        hist->fill(ksi); // fill histogramm
    }
    for(int i=0; i<hist->get_num_bin(); i++){
        cout << hist->get_bin(i) << "\t";   // get middle of bin boundary
        cout << hist->get_bin_value(i) << "\n"; // get number of counts in the bin
        }
    hist->draw(60);

    delete hist;  // destroy histogramm

}
