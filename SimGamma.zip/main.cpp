#include <iostream>
#include <math.h>
#include <time.h>
#include <algorithm>
#include "hist.hpp"

#ifndef M_PI
double M_PI = 3.14159265;
#endif

using namespace std;

// This function generates basic random
double gamma(){
	return (rand()+0.5)/(RAND_MAX+1.0);
}

// scattered photon energy probability
double g_compton(double x, double E){
	return x/E + E/x + (1/E - 1/x)*(2 + 1/E - 1/x);
}

// simulate compton
double compton(double E)
{
// *****************************************************
 double ksi, xmin, xmax, dx, x, sumP, xgrid[1001], Px[1000];
 double gam1;
 int i,counter;

 xmin=E/(1.+2.*E);
 xmax=E;
// *****************************************************












// *****************************************************
 return ksi;
}

double mu_phot(double E){return 0.1/E;}
double mu_compt(double E){return 0.05*E;}
double mu_pair(double E)
{
 if( E>2 ) return 0.023*(E-2);
 return 0;
}

int main()
{
	double d = 3;  // thickness
	double Einit = 8; // initial energy
	double Energy, Energy_gamma, Erelease, x, x_gamma;
	double ksi1, ksi2, ksi3, ksi, ksi_tmp;
	double gam1, gam2, sigma;
	srand(time(NULL)); // initialize the random generator
	int nstep, proc, i, k, num_bin = 51;
	Hist *hist = new Hist(-0.1, 10.1, num_bin);
	Hist *hist_pm = new Hist(-0.1, 10.1, num_bin);

	double de, de_pm;
	for( int i=0; i<500000; i++ )
    {
// *****************************************************















// *****************************************************
     hist->fill(de); // fill histogramm
// *****************************************************



// *****************************************************
     hist_pm->fill(de_pm); // fill histogramm
    }
    for(i=0; i<hist->get_num_bin(); i++)
    {
     cout << hist->get_bin(i) << "\t";   // get middle of bin boundary
     cout << hist->get_bin_value(i) << "\t"; // get number of counts in the bin
     cout << hist_pm->get_bin_value(i) << "\n"; // get number of counts in the bin
	}
	hist->draw(60);
	hist_pm->draw(60);

	delete hist;  // destroy histogramm
    delete hist_pm;  // destroy histogramm

 }

