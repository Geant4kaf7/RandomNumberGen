#include <stdlib.h>

class Hist{
    public:
    Hist(double l, double h, int n);
    ~Hist(){free(hh);}
    void fill(double ksi);
    void draw(int width);
    int get_bin_value(int n);
    double get_bin(int n);
    int get_num_bin(){return nc;}
    protected:
    int *hh;
    int nc;
    double lb, hb, step;
};


