#include <iostream>
#include <math.h>
#include <time.h>
#include "hist.hpp"

using namespace std;

// This function generates basic random
double gamma(){
    return (rand()+0.5)/(RAND_MAX+1.0);
}

int main(){
    srand(time(NULL)); // initialize the random generator
    int num_bin = 10;
    double ksi;
    Hist *hist = new Hist( 0., 1., num_bin);
    for( int i=0; i<4000000; i++ ){
        ksi = gamma();
        hist->fill(ksi); // fill histogram
    }

    for(int i=0; i<hist->get_num_bin(); i++){
        cout << hist->get_bin(i) << "\t";   // get middle of bin boundary
        cout << hist->get_bin_value(i) << "\n"; // get number of counts in the bin
    }
    hist->draw(60);
    delete hist;  // destroy histogram

}

